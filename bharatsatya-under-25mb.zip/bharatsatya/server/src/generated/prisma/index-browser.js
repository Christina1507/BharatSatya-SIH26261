
Object.defineProperty(exports, "__esModule", { value: true });

const {
  Decimal,
  objectEnumValues,
  makeStrictEnum,
  Public,
  getRuntime,
  skip
} = require('./runtime/index-browser.js')


const Prisma = {}

exports.Prisma = Prisma
exports.$Enums = {}

/**
 * Prisma Client JS version: 5.22.0
 * Query Engine version: 605197351a3c8bdd595af2d2a9bc3025bca48ea2
 */
Prisma.prismaVersion = {
  client: "5.22.0",
  engine: "605197351a3c8bdd595af2d2a9bc3025bca48ea2"
}

Prisma.PrismaClientKnownRequestError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientKnownRequestError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)};
Prisma.PrismaClientUnknownRequestError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientUnknownRequestError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientRustPanicError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientRustPanicError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientInitializationError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientInitializationError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientValidationError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientValidationError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.NotFoundError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`NotFoundError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.Decimal = Decimal

/**
 * Re-export of sql-template-tag
 */
Prisma.sql = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`sqltag is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.empty = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`empty is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.join = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`join is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.raw = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`raw is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.validator = Public.validator

/**
* Extensions
*/
Prisma.getExtensionContext = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`Extensions.getExtensionContext is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.defineExtension = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`Extensions.defineExtension is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}

/**
 * Shorthand utilities for JSON filtering
 */
Prisma.DbNull = objectEnumValues.instances.DbNull
Prisma.JsonNull = objectEnumValues.instances.JsonNull
Prisma.AnyNull = objectEnumValues.instances.AnyNull

Prisma.NullTypes = {
  DbNull: objectEnumValues.classes.DbNull,
  JsonNull: objectEnumValues.classes.JsonNull,
  AnyNull: objectEnumValues.classes.AnyNull
}



/**
 * Enums
 */

exports.Prisma.TransactionIsolationLevel = makeStrictEnum({
  ReadUncommitted: 'ReadUncommitted',
  ReadCommitted: 'ReadCommitted',
  RepeatableRead: 'RepeatableRead',
  Serializable: 'Serializable'
});

exports.Prisma.UserScalarFieldEnum = {
  id: 'id',
  email: 'email',
  passwordHash: 'passwordHash',
  googleSubject: 'googleSubject',
  name: 'name',
  role: 'role',
  department: 'department',
  designation: 'designation',
  institutionId: 'institutionId',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.InstitutionScalarFieldEnum = {
  id: 'id',
  name: 'name',
  aictePermanentId: 'aictePermanentId',
  address: 'address',
  state: 'state',
  district: 'district',
  pincode: 'pincode',
  contactEmail: 'contactEmail',
  contactPhone: 'contactPhone',
  establishedYear: 'establishedYear',
  category: 'category',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ApplicationScalarFieldEnum = {
  id: 'id',
  institutionId: 'institutionId',
  category: 'category',
  academicYear: 'academicYear',
  status: 'status',
  submissionDate: 'submissionDate',
  lastEvaluatedAt: 'lastEvaluatedAt',
  assignedReviewerId: 'assignedReviewerId',
  currentStage: 'currentStage',
  recommendedAction: 'recommendedAction',
  remarks: 'remarks',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.DocumentScalarFieldEnum = {
  id: 'id',
  applicationId: 'applicationId',
  documentType: 'documentType',
  title: 'title',
  fileName: 'fileName',
  originalName: 'originalName',
  mimeType: 'mimeType',
  fileSizeBytes: 'fileSizeBytes',
  fileHashSha256: 'fileHashSha256',
  storagePath: 'storagePath',
  uploadDate: 'uploadDate',
  status: 'status',
  isDuplicate: 'isDuplicate',
  duplicateOfDocumentId: 'duplicateOfDocumentId',
  ocrConfidence: 'ocrConfidence',
  ocrRawText: 'ocrRawText',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ExtractedFieldScalarFieldEnum = {
  id: 'id',
  documentId: 'documentId',
  applicationId: 'applicationId',
  fieldName: 'fieldName',
  fieldLabel: 'fieldLabel',
  fieldValue: 'fieldValue',
  originalExtractedValue: 'originalExtractedValue',
  confidence: 'confidence',
  isCorrected: 'isCorrected',
  correctedByUserId: 'correctedByUserId',
  correctedAt: 'correctedAt',
  evidencePage: 'evidencePage',
  evidenceSnippet: 'evidenceSnippet',
  evidenceCoordinates: 'evidenceCoordinates',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ValidationRuleScalarFieldEnum = {
  id: 'id',
  code: 'code',
  title: 'title',
  description: 'description',
  category: 'category',
  officialSourceReference: 'officialSourceReference',
  isOfficial: 'isOfficial',
  ruleType: 'ruleType',
  severity: 'severity',
  logicConfigJson: 'logicConfigJson',
  isActive: 'isActive',
  version: 'version',
  effectiveDate: 'effectiveDate',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ValidationRuleVersionScalarFieldEnum = {
  id: 'id',
  ruleId: 'ruleId',
  version: 'version',
  title: 'title',
  description: 'description',
  category: 'category',
  officialSourceReference: 'officialSourceReference',
  isOfficial: 'isOfficial',
  ruleType: 'ruleType',
  severity: 'severity',
  isActive: 'isActive',
  logicConfigJson: 'logicConfigJson',
  changedByUserId: 'changedByUserId',
  changeReason: 'changeReason',
  createdAt: 'createdAt'
};

exports.Prisma.ValidationFindingScalarFieldEnum = {
  id: 'id',
  applicationId: 'applicationId',
  ruleId: 'ruleId',
  ruleVersionId: 'ruleVersionId',
  documentId: 'documentId',
  status: 'status',
  severity: 'severity',
  title: 'title',
  message: 'message',
  evidenceLocation: 'evidenceLocation',
  evidenceSnippet: 'evidenceSnippet',
  evidenceComparisonJson: 'evidenceComparisonJson',
  reviewerAcknowledged: 'reviewerAcknowledged',
  acknowledgedByUserId: 'acknowledgedByUserId',
  acknowledgedAt: 'acknowledgedAt',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.VerificationRequestScalarFieldEnum = {
  id: 'id',
  applicationId: 'applicationId',
  requestedByUserId: 'requestedByUserId',
  documentId: 'documentId',
  provider: 'provider',
  referenceId: 'referenceId',
  requestedAt: 'requestedAt',
  completedAt: 'completedAt',
  status: 'status',
  responseSummary: 'responseSummary',
  evidenceReference: 'evidenceReference',
  rawResponseJson: 'rawResponseJson',
  isDemoSimulation: 'isDemoSimulation',
  createdAt: 'createdAt'
};

exports.Prisma.ReviewActionScalarFieldEnum = {
  id: 'id',
  applicationId: 'applicationId',
  reviewerId: 'reviewerId',
  actionType: 'actionType',
  previousStatus: 'previousStatus',
  newStatus: 'newStatus',
  reason: 'reason',
  notes: 'notes',
  createdAt: 'createdAt'
};

exports.Prisma.AuditEventScalarFieldEnum = {
  id: 'id',
  actorId: 'actorId',
  actorName: 'actorName',
  actorRole: 'actorRole',
  action: 'action',
  entityType: 'entityType',
  entityId: 'entityId',
  beforeStateJson: 'beforeStateJson',
  afterStateJson: 'afterStateJson',
  ipAddress: 'ipAddress',
  userAgent: 'userAgent',
  createdAt: 'createdAt'
};

exports.Prisma.NotificationScalarFieldEnum = {
  id: 'id',
  userId: 'userId',
  applicationId: 'applicationId',
  title: 'title',
  message: 'message',
  type: 'type',
  isRead: 'isRead',
  createdAt: 'createdAt'
};

exports.Prisma.SortOrder = {
  asc: 'asc',
  desc: 'desc'
};

exports.Prisma.QueryMode = {
  default: 'default',
  insensitive: 'insensitive'
};

exports.Prisma.NullsOrder = {
  first: 'first',
  last: 'last'
};
exports.UserRole = exports.$Enums.UserRole = {
  APPLICANT: 'APPLICANT',
  REVIEWER: 'REVIEWER',
  ADMIN: 'ADMIN'
};

exports.ApplicationStatus = exports.$Enums.ApplicationStatus = {
  SUBMITTED: 'SUBMITTED',
  UNDER_AUTOMATED_REVIEW: 'UNDER_AUTOMATED_REVIEW',
  DEFICIENCY_FLAGGED: 'DEFICIENCY_FLAGGED',
  CLARIFICATION_REQUESTED: 'CLARIFICATION_REQUESTED',
  VERIFIED_RECOMMENDED: 'VERIFIED_RECOMMENDED',
  REJECTED_NON_COMPLIANT: 'REJECTED_NON_COMPLIANT',
  APPROVED: 'APPROVED'
};

exports.DocumentType = exports.$Enums.DocumentType = {
  LAND_TITLE_DEED: 'LAND_TITLE_DEED',
  BUILDING_PLAN_APPROVAL: 'BUILDING_PLAN_APPROVAL',
  FIRE_SAFETY_NOC: 'FIRE_SAFETY_NOC',
  OCCUPANCY_CERTIFICATE: 'OCCUPANCY_CERTIFICATE',
  SOCIETY_TRUST_REGISTRATION: 'SOCIETY_TRUST_REGISTRATION',
  FDR_FINANCIAL_ENDOWMENT: 'FDR_FINANCIAL_ENDOWMENT',
  AICTE_PREVIOUS_EOA: 'AICTE_PREVIOUS_EOA'
};

exports.FindingSeverity = exports.$Enums.FindingSeverity = {
  CRITICAL: 'CRITICAL',
  MAJOR: 'MAJOR',
  MINOR: 'MINOR',
  INFO: 'INFO'
};

exports.FindingStatus = exports.$Enums.FindingStatus = {
  PASSED: 'PASSED',
  MISSING: 'MISSING',
  EXPIRED: 'EXPIRED',
  MISMATCH: 'MISMATCH',
  PENDING_VERIFICATION: 'PENDING_VERIFICATION',
  MANUAL_REVIEW_REQUIRED: 'MANUAL_REVIEW_REQUIRED'
};

exports.VerificationStatus = exports.$Enums.VerificationStatus = {
  VERIFIED: 'VERIFIED',
  MISMATCH_DETECTED: 'MISMATCH_DETECTED',
  EXPIRED: 'EXPIRED',
  PENDING: 'PENDING',
  SOURCE_UNAVAILABLE: 'SOURCE_UNAVAILABLE',
  MANUAL_REVIEW_REQUIRED: 'MANUAL_REVIEW_REQUIRED'
};

exports.ReviewActionType = exports.$Enums.ReviewActionType = {
  STATUS_CHANGE: 'STATUS_CHANGE',
  CLARIFICATION_REQUEST: 'CLARIFICATION_REQUEST',
  NOTE_ADDED: 'NOTE_ADDED',
  FINDING_OVERRIDE: 'FINDING_OVERRIDE',
  FIELD_CORRECTED: 'FIELD_CORRECTED'
};

exports.Prisma.ModelName = {
  User: 'User',
  Institution: 'Institution',
  Application: 'Application',
  Document: 'Document',
  ExtractedField: 'ExtractedField',
  ValidationRule: 'ValidationRule',
  ValidationRuleVersion: 'ValidationRuleVersion',
  ValidationFinding: 'ValidationFinding',
  VerificationRequest: 'VerificationRequest',
  ReviewAction: 'ReviewAction',
  AuditEvent: 'AuditEvent',
  Notification: 'Notification'
};

/**
 * This is a stub Prisma Client that will error at runtime if called.
 */
class PrismaClient {
  constructor() {
    return new Proxy(this, {
      get(target, prop) {
        let message
        const runtime = getRuntime()
        if (runtime.isEdge) {
          message = `PrismaClient is not configured to run in ${runtime.prettyName}. In order to run Prisma Client on edge runtime, either:
- Use Prisma Accelerate: https://pris.ly/d/accelerate
- Use Driver Adapters: https://pris.ly/d/driver-adapters
`;
        } else {
          message = 'PrismaClient is unable to run in this browser environment, or has been bundled for the browser (running in `' + runtime.prettyName + '`).'
        }
        
        message += `
If this is unexpected, please open an issue: https://pris.ly/prisma-prisma-bug-report`

        throw new Error(message)
      }
    })
  }
}

exports.PrismaClient = PrismaClient

Object.assign(exports, Prisma)
