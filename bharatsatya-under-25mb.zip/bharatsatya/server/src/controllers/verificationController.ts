import { Request, Response } from 'express';
import { z } from 'zod';
import { prisma } from '../prisma.js';
import { verificationAdapters } from '../verification/adapters.js';
import { writeAuditEvent } from '../services/audit.js';

const VerifySchema = z.object({
  applicationId: z.string().min(1),
  provider: z.string().min(1),
  referenceId: z.string().trim().min(1).max(160),
  documentId: z.string().optional(),
});

export async function requestVerification(req: Request, res: Response): Promise<void> {
  const parsed = VerifySchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ success: false, error: 'ValidationError', details: parsed.error.flatten() });
    return;
  }

  const { applicationId, provider, referenceId, documentId } = parsed.data;
  const adapter = verificationAdapters[provider];
  if (!adapter) {
    res.status(400).json({ success: false, error: 'UnsupportedVerificationProvider' });
    return;
  }

  try {
    const application = await prisma.application.findUnique({ where: { id: applicationId } });
    if (!application) {
      res.status(404).json({ success: false, error: 'ApplicationNotFound' });
      return;
    }
    if (documentId) {
      const document = await prisma.document.findFirst({ where: { id: documentId, applicationId } });
      if (!document) {
        res.status(400).json({ success: false, error: 'DocumentNotInApplication' });
        return;
      }
    }

    // Adapters are explicitly simulations. A future live adapter must have its
    // own credential/configuration path and must not impersonate an authority.
    const result = await adapter.verify(referenceId, { applicationId, category: application.category });
    const created = await prisma.$transaction(async (tx) => {
      const verification = await tx.verificationRequest.create({
        data: {
          applicationId,
          documentId,
          requestedByUserId: req.user!.id,
          provider: result.provider,
          referenceId: result.referenceId,
          requestedAt: result.requestedAt,
          completedAt: new Date(),
          status: result.status,
          responseSummary: result.responseSummary,
          evidenceReference: result.evidenceReference,
          rawResponseJson: result.rawResponse ? JSON.stringify(result.rawResponse) : null,
          isDemoSimulation: result.isDemoSimulation,
        },
      });
      await writeAuditEvent(tx, {
        actorId: req.user!.id, actorName: req.user!.name, actorRole: req.user!.role,
        action: 'VERIFICATION_REQUESTED', entityType: 'VerificationRequest', entityId: verification.id,
        afterState: {
          applicationId, documentId: documentId || null, provider: result.provider,
          requestedAt: result.requestedAt.toISOString(), status: result.status,
          evidenceReference: result.evidenceReference, isDemoSimulation: result.isDemoSimulation,
        },
        ipAddress: req.ip, userAgent: req.headers['user-agent'],
      });
      return verification;
    });

    res.status(201).json({ success: true, data: created });
  } catch (error: any) {
    res.status(500).json({ success: false, error: 'InternalServerError' });
  }
}
